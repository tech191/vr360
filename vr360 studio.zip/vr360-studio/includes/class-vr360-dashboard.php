<?php
/**
 * VR360 Dashboard Class
 * 
 * ⭐ CLASS NÀY RENDER GIAO DIỆN DASHBOARD
 * (HTML từ mockup "VR360 Studio - Dashboard")
 */

class VR360_Dashboard {
    
    /**
     * ⭐⭐⭐ HÀM CHÍNH - RENDER DASHBOARD ⭐⭐⭐
     * 
     * Function này được gọi khi:
     * - User click "VR360 Studio" trong menu WordPress
     * - Được gọi từ add_menu_page() trong main plugin file
     */
    public static function render() {
        // Check permission
        if (!current_user_can('edit_posts')) {
            wp_die(__('You do not have permission to access this page.'));
        }
        
        // Get current user data
        $user_id = get_current_user_id();
        $user = wp_get_current_user();
        
        // Get user's tours
        $tours = self::get_user_tours($user_id);
        
        // Get statistics
        $stats = self::get_user_stats($user_id);
        
        // Get storage info
        $storage = self::get_storage_info($user_id);
        
        // ═══════════════════════════════════════
        // ⭐ LOAD TEMPLATE FILE
        // (File này chứa HTML từ mockup Dashboard)
        // ═══════════════════════════════════════
        include VR360_PLUGIN_DIR . 'templates/dashboard-page.php';
    }
    
    /**
     * Get user's tours from database
     */
    private static function get_user_tours($user_id, $limit = 10) {
        global $wpdb;
        $table = $wpdb->prefix . 'vr360_tours';
        
        $tours = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table 
            WHERE author_id = %d 
            ORDER BY modified_date DESC 
            LIMIT %d",
            $user_id,
            $limit
        ));
        
        // Add view counts
        foreach ($tours as &$tour) {
            $tour->views = self::get_tour_views($tour->id);
        }
        
        return $tours;
    }
    
    /**
     * Get user statistics
     */
    private static function get_user_stats($user_id) {
        global $wpdb;
        $tours_table = $wpdb->prefix . 'vr360_tours';
        $stats_table = $wpdb->prefix . 'vr360_stats';
        
        // Total tours
        $total_tours = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $tours_table WHERE author_id = %d",
            $user_id
        ));
        
        // Total views
        $total_views = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(s.view_count) 
            FROM $stats_table s
            INNER JOIN $tours_table t ON s.tour_id = t.id
            WHERE t.author_id = %d",
            $user_id
        ));
        
        // Tours created this week
        $tours_this_week = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) 
            FROM $tours_table 
            WHERE author_id = %d 
            AND created_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)",
            $user_id
        ));
        
        return array(
            'total_tours' => intval($total_tours),
            'total_views' => intval($total_views),
            'tours_this_week' => intval($tours_this_week),
            'avg_time' => '4.2 min', // TODO: Calculate from analytics
        );
    }
    
    /**
     * Get storage information
     */
    private static function get_storage_info($user_id) {
        $used_bytes = get_user_meta($user_id, 'vr360_storage_used', true);
        $used_bytes = $used_bytes ? intval($used_bytes) : 0;
        
        // Get user's plan storage limit
        $limit_bytes = 50 * 1024 * 1024 * 1024; // 50GB default (Pro plan)
        
        $used_gb = round($used_bytes / (1024 * 1024 * 1024), 2);
        $limit_gb = round($limit_bytes / (1024 * 1024 * 1024));
        $percentage = ($used_bytes / $limit_bytes) * 100;
        
        return array(
            'used_gb' => $used_gb,
            'limit_gb' => $limit_gb,
            'percentage' => round($percentage, 1),
            'available_gb' => $limit_gb - $used_gb,
        );
    }
    
    /**
     * Get tour view count
     */
    private static function get_tour_views($tour_id) {
        global $wpdb;
        $stats_table = $wpdb->prefix . 'vr360_stats';
        
        $views = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(view_count) FROM $stats_table WHERE tour_id = %d",
            $tour_id
        ));
        
        return $views ? intval($views) : 0;
    }
    
    /**
     * Render "All Tours" page
     */
    public static function render_all_tours() {
        if (!current_user_can('edit_posts')) {
            wp_die(__('You do not have permission to access this page.'));
        }
        
        $user_id = get_current_user_id();
        $tours = self::get_user_tours($user_id, 999);
        
        include VR360_PLUGIN_DIR . 'templates/all-tours-page.php';
    }
    
    /**
     * Get user's plan
     */
    private static function get_user_plan($user_id) {
        // TODO: Integrate with MemberPress or other membership plugin
        return 'Pro Plan';
    }
}