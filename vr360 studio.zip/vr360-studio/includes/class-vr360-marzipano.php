<?php
/**
 * VR360 Marzipano Integration Class
 * Handles Marzipano viewer initialization and management
 */

if (!defined('ABSPATH')) exit;

class VR360_Marzipano {
    
    /**
     * Enqueue Marzipano assets
     */
    public static function enqueue_assets() {
        // Enqueue Marzipano library
        wp_enqueue_script(
            'marzipano',
            VR360_PLUGIN_URL . 'assets/marzipano/marzipano.js',
            array(),
            '0.10.2',
            true
        );
        
        // Enqueue our Marzipano integration script
        wp_enqueue_script(
            'vr360-marzipano-integration',
            VR360_PLUGIN_URL . 'assets/js/marzipano-integration.js',
            array('jquery', 'marzipano'),
            VR360_VERSION,
            true
        );
    }
    
    /**
     * Get default Marzipano viewer configuration
     */
    public static function get_default_config() {
        return array(
            'controls' => array(
                'mouseViewMode' => 'drag'
            ),
            'settings' => array(
                'mouseViewMode' => 'drag',
                'autorotateEnabled' => false,
                'fullscreenButton' => true,
                'viewControlButtons' => true
            )
        );
    }
    
    /**
     * Generate viewer configuration for a scene
     */
    public static function get_scene_config($scene_data) {
        $config = array(
            'source' => array(
                'type' => 'image',
                'url' => $scene_data['image_url']
            ),
            'geometry' => array(
                'type' => 'equirectangular',
                'levels' => array(
                    array('width' => 4096),
                    array('width' => 2048),
                    array('width' => 1024)
                )
            ),
            'view' => array(
                'type' => 'rectilinear',
                'yaw' => 0,
                'pitch' => 0,
                'fov' => 1.5708 // 90 degrees in radians
            ),
            'hotspots' => array()
        );
        
        // Add hotspots if available
        if (isset($scene_data['hotspots']) && is_array($scene_data['hotspots'])) {
            $config['hotspots'] = self::format_hotspots($scene_data['hotspots']);
        }
        
        return $config;
    }
    
    /**
     * Format hotspots for Marzipano
     */
    private static function format_hotspots($hotspots) {
        $formatted = array();
        
        foreach ($hotspots as $hotspot) {
            $formatted[] = array(
                'yaw' => isset($hotspot['yaw']) ? floatval($hotspot['yaw']) : 0,
                'pitch' => isset($hotspot['pitch']) ? floatval($hotspot['pitch']) : 0,
                'type' => isset($hotspot['type']) ? $hotspot['type'] : 'info',
                'title' => isset($hotspot['title']) ? $hotspot['title'] : '',
                'description' => isset($hotspot['description']) ? $hotspot['description'] : '',
                'target_scene' => isset($hotspot['target_scene']) ? $hotspot['target_scene'] : null,
                'icon' => isset($hotspot['icon']) ? $hotspot['icon'] : '📍'
            );
        }
        
        return $formatted;
    }
    
    /**
     * Generate multi-scene tour configuration
     */
    public static function get_tour_config($tour_data) {
        $scenes_data = json_decode($tour_data->scenes_data, true);
        
        if (empty($scenes_data)) {
            return null;
        }
        
        $config = array(
            'name' => $tour_data->tour_name,
            'settings' => self::get_default_config(),
            'scenes' => array()
        );
        
        foreach ($scenes_data as $scene) {
            $config['scenes'][$scene['id']] = self::get_scene_config($scene);
        }
        
        // Set first scene as default
        $first_scene = reset($scenes_data);
        $config['default_scene'] = $first_scene['id'];
        
        return $config;
    }
    
    /**
     * Render viewer HTML
     */
    public static function render_viewer($container_id = 'vr360-viewer') {
        ?>
        <div id="<?php echo esc_attr($container_id); ?>" 
             class="vr360-viewer-container" 
             style="width: 100%; height: 100%; position: relative;">
            <div class="vr360-loading">
                <div class="vr360-spinner"></div>
                <p>Loading panorama...</p>
            </div>
        </div>
        <?php
    }
    
    /**
     * Generate embed code
     */
    public static function generate_embed_code($tour_id, $width = '100%', $height = '600px') {
        $tour_url = home_url('/vr360-tour/' . $tour_id);
        
        $embed_code = sprintf(
            '<iframe src="%s" width="%s" height="%s" frameborder="0" allowfullscreen allow="vr"></iframe>',
            esc_url($tour_url),
            esc_attr($width),
            esc_attr($height)
        );
        
        return $embed_code;
    }
    
    /**
     * Generate shortcode
     */
    public static function generate_shortcode($tour_id) {
        return sprintf('[vr360_tour id="%d"]', $tour_id);
    }
}