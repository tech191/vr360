<?php
if (!defined('ABSPATH')) exit;

class VR360_Ajax {
    
    public static function upload_image() {
        check_ajax_referer('vr360_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permission denied');
        }
        
        if (empty($_FILES['image'])) {
            wp_send_json_error('No file uploaded');
        }
        
        $file = $_FILES['image'];
        
        $upload_dir = wp_upload_dir();
        $vr360_dir = $upload_dir['basedir'] . '/vr360-tours';
        $user_id = get_current_user_id();
        $user_dir = $vr360_dir . '/user_' . $user_id;
        
        if (!file_exists($user_dir)) {
            wp_mkdir_p($user_dir);
        }
        
        $filename = time() . '_' . sanitize_file_name($file['name']);
        $filepath = $user_dir . '/' . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            $file_url = $upload_dir['baseurl'] . '/vr360-tours/user_' . $user_id . '/' . $filename;
            
            wp_send_json_success(array(
                'url' => $file_url,
                'path' => $filepath,
            ));
        } else {
            wp_send_json_error('Upload failed');
        }
    }
    
    public static function save_tour() {
        check_ajax_referer('vr360_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Permission denied');
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'vr360_tours';
        
        $tour_id = isset($_POST['tour_id']) ? intval($_POST['tour_id']) : 0;
        $tour_name = sanitize_text_field($_POST['tour_name']);
        $scenes = $_POST['scenes'];
        
        $data = array(
            'tour_name' => $tour_name,
            'scenes_data' => $scenes,
            'author_id' => get_current_user_id(),
            'modified_date' => current_time('mysql'),
        );
        
        if ($tour_id > 0) {
            $wpdb->update($table, $data, array('id' => $tour_id));
            wp_send_json_success(array('tour_id' => $tour_id));
        } else {
            $data['created_date'] = current_time('mysql');
            $wpdb->insert($table, $data);
            wp_send_json_success(array('tour_id' => $wpdb->insert_id));
        }
    }
    
    public static function get_tours() {
        check_ajax_referer('vr360_nonce', 'nonce');
        
        global $wpdb;
        $table = $wpdb->prefix . 'vr360_tours';
        
        $tours = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE author_id = %d ORDER BY modified_date DESC",
            get_current_user_id()
        ));
        
        wp_send_json_success($tours);
    }
    
    public static function delete_tour() {
        check_ajax_referer('vr360_nonce', 'nonce');
        
        if (!current_user_can('delete_posts')) {
            wp_send_json_error('Permission denied');
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'vr360_tours';
        $tour_id = intval($_POST['tour_id']);
        
        $wpdb->delete($table, array(
            'id' => $tour_id,
            'author_id' => get_current_user_id()
        ));
        
        wp_send_json_success('Deleted');
    }
}