<?php
/**
 * VR360 Core Class
 * Contains core utility functions
 */

if (!defined('ABSPATH')) exit;

class VR360_Core {
    
    /**
     * Get upload directory for VR360
     */
    public static function get_upload_dir() {
        $upload_dir = wp_upload_dir();
        $vr360_dir = $upload_dir['basedir'] . '/vr360-tours';
        
        if (!file_exists($vr360_dir)) {
            wp_mkdir_p($vr360_dir);
        }
        
        return array(
            'path' => $vr360_dir,
            'url' => $upload_dir['baseurl'] . '/vr360-tours'
        );
    }
    
    /**
     * Get user's upload directory
     */
    public static function get_user_upload_dir($user_id) {
        $vr360_dir = self::get_upload_dir();
        $user_dir = $vr360_dir['path'] . '/user_' . $user_id;
        
        if (!file_exists($user_dir)) {
            wp_mkdir_p($user_dir);
        }
        
        return array(
            'path' => $user_dir,
            'url' => $vr360_dir['url'] . '/user_' . $user_id
        );
    }
    
    /**
     * Validate 360 image
     */
    public static function validate_360_image($file) {
        $errors = array();
        
        // Check file type
        $allowed_types = array('image/jpeg', 'image/png', 'image/jpg');
        if (!in_array($file['type'], $allowed_types)) {
            $errors[] = 'Invalid file type. Only JPG and PNG allowed.';
        }
        
        // Check file size (20MB max)
        if ($file['size'] > 20 * 1024 * 1024) {
            $errors[] = 'File size exceeds 20MB limit.';
        }
        
        // Check image dimensions (should be 2:1 ratio for equirectangular)
        if (empty($errors)) {
            $image_info = getimagesize($file['tmp_name']);
            if ($image_info) {
                $width = $image_info[0];
                $height = $image_info[1];
                $ratio = $width / $height;
                
                // Equirectangular images should have 2:1 ratio
                if ($ratio < 1.9 || $ratio > 2.1) {
                    $errors[] = 'Warning: Image ratio is ' . round($ratio, 2) . ':1. Equirectangular images should be 2:1.';
                }
            }
        }
        
        return $errors;
    }
    
    /**
     * Format file size
     */
    public static function format_bytes($bytes, $precision = 2) {
        $units = array('B', 'KB', 'MB', 'GB', 'TB');
        
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        $bytes /= pow(1024, $pow);
        
        return round($bytes, $precision) . ' ' . $units[$pow];
    }
    
    /**
     * Get user storage usage
     */
    public static function get_user_storage_usage($user_id) {
        $used_bytes = get_user_meta($user_id, 'vr360_storage_used', true);
        $used_bytes = $used_bytes ? intval($used_bytes) : 0;
        
        // Get user's plan limit (default 50GB for Pro)
        $limit_bytes = apply_filters('vr360_storage_limit', 50 * 1024 * 1024 * 1024, $user_id);
        
        return array(
            'used_bytes' => $used_bytes,
            'limit_bytes' => $limit_bytes,
            'used_formatted' => self::format_bytes($used_bytes),
            'limit_formatted' => self::format_bytes($limit_bytes),
            'percentage' => ($used_bytes / $limit_bytes) * 100,
            'available_bytes' => $limit_bytes - $used_bytes,
        );
    }
    
    /**
     * Update user storage usage
     */
    public static function update_storage_usage($user_id, $bytes_added) {
        $current = get_user_meta($user_id, 'vr360_storage_used', true);
        $current = $current ? intval($current) : 0;
        $new_total = $current + $bytes_added;
        
        update_user_meta($user_id, 'vr360_storage_used', $new_total);
        
        return $new_total;
    }
    
    /**
     * Generate unique filename
     */
    public static function generate_unique_filename($original_name) {
        $ext = pathinfo($original_name, PATHINFO_EXTENSION);
        $name = pathinfo($original_name, PATHINFO_FILENAME);
        $name = sanitize_file_name($name);
        
        return time() . '_' . uniqid() . '_' . $name . '.' . $ext;
    }
    
    /**
     * Check if user can upload more
     */
    public static function can_user_upload($user_id, $file_size) {
        $storage = self::get_user_storage_usage($user_id);
        
        if ($storage['available_bytes'] < $file_size) {
            return array(
                'can_upload' => false,
                'message' => 'Storage limit exceeded. Available: ' . self::format_bytes($storage['available_bytes'])
            );
        }
        
        return array('can_upload' => true);
    }
}