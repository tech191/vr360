/**
 * VR360 Editor with Marzipano Integration
 */

(function($) {
    'use strict';
    
    const VR360Editor = {
        viewer: null,
        currentScene: null,
        scenes: [],
        hotspots: [],
        selectedHotspot: null,
        currentTool: 'select',
        isDirty: false,
        
        /**
         * Initialize editor
         */
        init: function() {
            console.log('🎯 VR360 Editor with Marzipano initializing...');
            
            this.initUpload();
            this.initSave();
            this.initPreview();
            this.loadExistingData();
            
            // Auto-save every 2 minutes
            setInterval(() => this.autoSave(), 120000);
            
            // Warn before leaving
            window.addEventListener('beforeunload', (e) => {
                if (this.isDirty) {
                    e.preventDefault();
                    e.returnValue = 'You have unsaved changes';
                }
            });
            
            console.log('✅ Editor initialized');
        },
        
        /**
         * Initialize upload
         */
        initUpload: function() {
            $('#vr360-file-input').on('change', (e) => {
                const file = e.target.files[0];
                if (!file) return;
                
                console.log('📤 Uploading:', file.name);
                this.uploadImage(file);
            });
        },
        
        /**
         * Upload image
         */
        uploadImage: function(file) {
            // Validate
            if (!file.type.match('image.*')) {
                alert('❌ Please upload only image files');
                return;
            }
            
            if (file.size > 20 * 1024 * 1024) {
                alert('❌ File size must be under 20MB');
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'vr360_upload_image');
            formData.append('nonce', $('#vr360-nonce').val());
            formData.append('tour_id', $('#vr360-tour-id').val());
            formData.append('image', file);
            
            $.ajax({
                url: vr360_ajax.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: (response) => {
                    if (response.success) {
                        console.log('✅ Upload success:', response.data);
                        
                        this.addScene({
                            id: 'scene_' + Date.now(),
                            name: file.name.replace(/\.[^/.]+$/, ''),
                            image_url: response.data.url,
                            image_path: response.data.path,
                            hotspots: []
                        });
                        
                        alert('✅ Image uploaded successfully!');
                    } else {
                        alert('❌ Upload failed: ' + response.data);
                    }
                },
                error: (xhr, status, error) => {
                    console.error('Upload error:', error);
                    alert('❌ Upload failed: ' + error);
                }
            });
        },
        
        /**
         * Add scene
         */
        addScene: function(scene) {
            this.scenes.push(scene);
            this.renderScenes();
            this.markDirty();
            
            // Auto-select first scene
            if (this.scenes.length === 1) {
                this.selectScene(scene.id);
            }
        },
        
        /**
         * Render scenes list
         */
        renderScenes: function() {
            const $container = $('#scenes-container');
            $container.empty();
            
            if (this.scenes.length === 0) {
                $container.html('<p>No scenes yet. Upload your first 360° image!</p>');
                return;
            }
            
            this.scenes.forEach((scene, index) => {
                const $card = $(`
                    <div class="scene-card" data-scene-id="${scene.id}">
                        <img src="${scene.image_url}" alt="${scene.name}">
                        <h4>Scene ${index + 1}: ${scene.name}</h4>
                        <p>${scene.hotspots.length} hotspots</p>
                        <button class="button" onclick="VR360Editor.selectScene('${scene.id}')">
                            Edit Scene
                        </button>
                    </div>
                `);
                
                $container.append($card);
            });
        },
        
        /**
         * Select scene and initialize Marzipano viewer
         */
        selectScene: function(sceneId) {
            const scene = this.scenes.find(s => s.id === sceneId);
            if (!scene) {
                console.error('Scene not found:', sceneId);
                return;
            }
            
            console.log('📍 Selecting scene:', scene.name);
            this.currentScene = scene;
            
            // Update UI
            $('.scene-card').removeClass('active');
            $(`.scene-card[data-scene-id="${sceneId}"]`).addClass('active');
            
            // Initialize Marzipano viewer
            this.initMarzipanoViewer(scene);
        },
        
        /**
         * Initialize Marzipano viewer
         */
        initMarzipanoViewer: function(scene) {
            console.log('🌐 Initializing Marzipano for:', scene.name);
            
            // Check if Marzipano is loaded
            if (typeof Marzipano === 'undefined') {
                console.error('❌ Marzipano library not loaded!');
                alert('Error: Marzipano library not loaded. Please refresh the page.');
                return;
            }
            
            const viewerDiv = document.getElementById('vr360-marzipano-viewer');
            if (!viewerDiv) {
                console.error('❌ Viewer container not found!');
                return;
            }
            
            // Destroy existing viewer
            if (this.viewer) {
                this.viewer.destroy();
            }
            
            // Create viewer
            this.viewer = new Marzipano.Viewer(viewerDiv, {
                controls: {
                    mouseViewMode: 'drag'
                }
            });
            
            // Create source
            const source = Marzipano.ImageUrlSource.fromString(scene.image_url);
            
            // Create geometry
            const geometry = new Marzipano.EquirectGeometry([
                { width: 4096 },
                { width: 2048 },
                { width: 1024 }
            ]);
            
            // Create view
            const view = new Marzipano.RectilinearView({
                yaw: 0,
                pitch: 0,
                fov: Math.PI / 2
            });
            
            // Create scene
            const marzipanoScene = this.viewer.createScene({
                source: source,
                geometry: geometry,
                view: view,
                pinFirstLevel: true
            });
            
            // Switch to scene
            marzipanoScene.switchTo({
                transitionDuration: 1000
            });
            
            console.log('✅ Marzipano viewer initialized');
            
            // Load hotspots
            if (scene.hotspots && scene.hotspots.length > 0) {
                this.loadHotspots(marzipanoScene, scene.hotspots);
            }
        },
        
        /**
         * Load hotspots into scene
         */
        loadHotspots: function(scene, hotspots) {
            const container = scene.hotspotContainer();
            
            hotspots.forEach(hotspot => {
                const element = document.createElement('div');
                element.className = 'vr360-hotspot';
                element.innerHTML = hotspot.icon || '📍';
                element.setAttribute('data-hotspot-id', hotspot.id);
                
                container.createHotspot(element, {
                    yaw: hotspot.yaw || 0,
                    pitch: hotspot.pitch || 0
                });
                
                element.addEventListener('click', () => {
                    this.selectHotspot(hotspot.id);
                });
            });
            
            console.log(`✅ Loaded ${hotspots.length} hotspots`);
        },
        
        /**
         * Initialize save
         */
        initSave: function() {
            $('#vr360-save-btn').on('click', () => {
                this.saveTour();
            });
        },
        
        /**
         * Save tour
         */
        saveTour: function() {
            console.log('💾 Saving tour...');
            
            $.ajax({
                url: vr360_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'vr360_save_tour',
                    nonce: $('#vr360-nonce').val(),
                    tour_id: $('#vr360-tour-id').val(),
                    tour_name: $('#vr360-tour-name').val(),
                    scenes: JSON.stringify(this.scenes)
                },
                success: (response) => {
                    if (response.success) {
                        console.log('✅ Tour saved:', response.data);
                        alert('✅ Tour saved successfully!');
                        this.isDirty = false;
                        
                        // Update tour ID if new
                        if ($('#vr360-tour-id').val() === '0') {
                            $('#vr360-tour-id').val(response.data.tour_id);
                        }
                    } else {
                        alert('❌ Save failed: ' + response.data);
                    }
                },
                error: () => {
                    alert('❌ Save failed');
                }
            });
        },
        
        /**
         * Auto-save
         */
        autoSave: function() {
            if (this.isDirty && this.scenes.length > 0) {
                console.log('💾 Auto-saving...');
                this.saveTour();
            }
        },
        
        /**
         * Initialize preview
         */
        initPreview: function() {
            $('#vr360-preview-btn').on('click', () => {
                this.previewTour();
            });
        },
        
        /**
         * Preview tour
         */
        previewTour: function() {
            const tourId = $('#vr360-tour-id').val();
            if (tourId === '0') {
                alert('❌ Please save the tour first');
                return;
            }
            
            const previewUrl = '/vr360-tour/' + tourId + '?preview=1';
            window.open(previewUrl, '_blank');
        },
        
        /**
         * Load existing data
         */
        loadExistingData: function() {
            const tourId = $('#vr360-tour-id').val();
            if (tourId === '0') return;
            
            console.log('📥 Loading tour data...');
            
            // TODO: Implement load tour data via AJAX
        },
        
        /**
         * Mark dirty
         */
        markDirty: function() {
            this.isDirty = true;
        },
        
        /**
         * Select hotspot
         */
        selectHotspot: function(hotspotId) {
            console.log('📍 Selected hotspot:', hotspotId);
            // TODO: Show hotspot properties panel
        }
    };
    
    // Initialize on document ready
    $(document).ready(function() {
        // Check if we're on editor page
        if ($('#vr360-file-input').length > 0) {
            VR360Editor.init();
        }
    });
    
    // Expose to window for debugging
    window.VR360Editor = VR360Editor;
    
})(jQuery);