<?php if (!defined('ABSPATH')) exit; ?>

<div class="wrap">
    <h1>🎯 VR360 Studio Dashboard</h1>
    
    <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h2>Welcome, <?php echo esc_html($user->display_name); ?>!</h2>
        
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin: 20px 0;">
            <div style="background: #f0f0f0; padding: 20px; border-radius: 8px;">
                <h3><?php echo $stats['total_tours']; ?></h3>
                <p>Total Tours</p>
            </div>
            <div style="background: #f0f0f0; padding: 20px; border-radius: 8px;">
                <h3><?php echo $stats['total_views']; ?></h3>
                <p>Total Views</p>
            </div>
            <div style="background: #f0f0f0; padding: 20px; border-radius: 8px;">
                <h3><?php echo $stats['tours_this_week']; ?></h3>
                <p>This Week</p>
            </div>
        </div>
        
        <a href="?page=vr360-editor" class="button button-primary button-large">
            ➕ Create New Tour
        </a>
    </div>
    
    <div style="background: white; padding: 20px; border-radius: 8px;">
        <h2>Recent Tours</h2>
        
        <?php if (empty($tours)): ?>
            <p>No tours yet. Create your first tour!</p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Tour Name</th>
                        <th>Scenes</th>
                        <th>Status</th>
                        <th>Modified</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tours as $tour): ?>
                        <tr>
                            <td><strong><?php echo esc_html($tour->tour_name); ?></strong></td>
                            <td><?php echo $tour->scene_count; ?></td>
                            <td><?php echo esc_html($tour->status); ?></td>
                            <td><?php echo human_time_diff(strtotime($tour->modified_date)); ?> ago</td>
                            <td>
                                <a href="?page=vr360-editor&tour_id=<?php echo $tour->id; ?>" class="button">Edit</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>