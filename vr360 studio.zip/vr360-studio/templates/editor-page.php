<?php if (!defined('ABSPATH')) exit; ?>

<div class="wrap">
    <h1>🎨 VR360 Tour Editor</h1>
    
    <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <div style="margin-bottom: 20px;">
            <label>Tour Name:</label><br>
            <input type="text" id="vr360-tour-name" 
                   value="<?php echo $tour_data ? esc_attr($tour_data->tour_name) : 'New Tour'; ?>" 
                   style="width: 100%; max-width: 500px; padding: 8px;">
        </div>
        
        <div style="margin-bottom: 20px;">
            <label>Upload 360° Image:</label><br>
            <input type="file" id="vr360-file-input" accept="image/*">
            <p class="description">Upload equirectangular 360° panorama images (JPG, PNG - Max 20MB)</p>
        </div>
        
        <div id="vr360-scenes-list" style="margin: 20px 0;">
            <h3>Scenes</h3>
            <div id="scenes-container"></div>
        </div>
        
        <!-- ⭐ MARZIPANO VIEWER CONTAINER -->
        <div id="vr360-viewer-section" style="margin: 20px 0; display: none;">
            <h3>360° Viewer</h3>
            <div id="vr360-marzipano-viewer" style="width: 100%; height: 600px; background: #000; border-radius: 8px;"></div>
        </div>
        
        <div style="margin-top: 20px;">
            <button id="vr360-save-btn" class="button button-primary button-large">💾 Save Tour</button>
            <button id="vr360