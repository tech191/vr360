# VR360 Studio WordPress Plugin

Create and manage VR360 virtual tours with ease.

## Installation

1. Upload the `vr360-studio` folder to `/wp-content/plugins/`
2. Activate the plugin through WordPress admin
3. Access via "VR360 Studio" menu

## Features

- Upload 360° panorama images
- Create virtual tours
- Manage multiple tours
- User dashboard
- Tour editor

## Requirements

- WordPress 5.8+
- PHP 7.4+

## License

GPL v2 or later