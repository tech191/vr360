<?php
/**
 * Plugin Name: VR360 Studio
 * Plugin URI: https://yourdomain.com
 * Description: Create and manage VR360 virtual tours with Marzipano
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 * Text Domain: vr360-studio
 */

// Prevent direct access
if (!defined('ABSPATH')) exit;

// Plugin constants
define('VR360_VERSION', '1.0.0');
define('VR360_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('VR360_PLUGIN_URL', plugin_dir_url(__FILE__));
define('VR360_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main VR360 Studio Class
 * 
 * ĐÂY LÀ "BỘ NÃO" CỦA PLUGIN
 * - Load các class khác
 * - Tạo menu trong WordPress Admin
 * - Kết nối Dashboard và Editor với WordPress
 */
class VR360_Studio {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Load tất cả files PHP cần thiết
        $this->load_dependencies();
        
        // Đăng ký các hooks với WordPress
        $this->init_hooks();
    }
    
    /**
     * Load các class PHP
     * MỖI CLASS = 1 CHỨC NĂNG
     */
private function load_dependencies() {
    require_once VR360_PLUGIN_DIR . 'includes/class-vr360-core.php';
    require_once VR360_PLUGIN_DIR . 'includes/class-vr360-database.php';
    require_once VR360_PLUGIN_DIR . 'includes/class-vr360-dashboard.php';
    require_once VR360_PLUGIN_DIR . 'includes/class-vr360-editor.php';
    require_once VR360_PLUGIN_DIR . 'includes/class-vr360-ajax.php';
    require_once VR360_PLUGIN_DIR . 'includes/class-vr360-marzipano.php';
}
    
    /**
     * Đăng ký hooks với WordPress
     * HOOKS = "ĐIỂM KẾT NỐI" giữa plugin và WordPress
     */
    private function init_hooks() {
        // Khi activate plugin → Tạo database tables
        register_activation_hook(__FILE__, array($this, 'activate'));
        
        // Khi WordPress init → Đăng ký các thứ cần thiết
        add_action('init', array($this, 'init'));
        
        // ⭐ TẠO MENU trong WordPress Admin
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // ⭐ Load CSS/JS cho Dashboard và Editor
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // ⭐ Đăng ký AJAX endpoints
        add_action('wp_ajax_vr360_save_tour', array('VR360_Ajax', 'save_tour'));
        add_action('wp_ajax_vr360_upload_image', array('VR360_Ajax', 'upload_image'));
        add_action('wp_ajax_vr360_get_tours', array('VR360_Ajax', 'get_tours'));
        add_action('wp_ajax_vr360_delete_tour', array('VR360_Ajax', 'delete_tour'));
    }
    
    /**
     * Activate plugin
     */
    public function activate() {
        // Tạo database tables
        VR360_Database::create_tables();
        
        // Tạo upload folders
        $upload_dir = wp_upload_dir();
        $vr360_dir = $upload_dir['basedir'] . '/vr360-tours';
        
        if (!file_exists($vr360_dir)) {
            wp_mkdir_p($vr360_dir);
        }
        
        flush_rewrite_rules();
    }
    
    /**
     * Init
     */
    public function init() {
        // Load text domain for translations
        load_plugin_textdomain('vr360-studio', false, dirname(VR360_PLUGIN_BASENAME) . '/languages');
    }
    
    /**
     * ⭐⭐⭐ TẠO MENU TRONG WORDPRESS ADMIN ⭐⭐⭐
     * ĐÂY LÀ CÁCH DASHBOARD VÀ EDITOR XUẤT HIỆN!
     */
    public function add_admin_menu() {
        // Main menu item
        add_menu_page(
            'VR360 Studio',              // Page title
            'VR360 Studio',              // Menu title
            'edit_posts',                // Capability (ai được phép truy cập)
            'vr360-dashboard',           // Menu slug (URL)
            array('VR360_Dashboard', 'render'),  // ⭐ Function render Dashboard
            'dashicons-format-gallery',  // Icon
            30                          // Position
        );
        
        // ⭐ Submenu: Dashboard
        add_submenu_page(
            'vr360-dashboard',
            'Dashboard',
            'Dashboard',
            'edit_posts',
            'vr360-dashboard',
            array('VR360_Dashboard', 'render')  // ⭐ Gọi Dashboard::render()
        );
        
        // ⭐ Submenu: Editor (Create New Tour)
        add_submenu_page(
            'vr360-dashboard',
            'Create New Tour',
            'Create New Tour',
            'edit_posts',
            'vr360-editor',
            array('VR360_Editor', 'render')     // ⭐ Gọi Editor::render()
        );
        
        // Submenu: All Tours
        add_submenu_page(
            'vr360-dashboard',
            'All Tours',
            'All Tours',
            'edit_posts',
            'vr360-all-tours',
            array('VR360_Dashboard', 'render_all_tours')
        );
    }
    
    /**
     * ⭐⭐⭐ LOAD CSS & JS ⭐⭐⭐
     * ĐÂY LÀ CÁCH GIAO DIỆN MOCKUP ĐƯỢC LOAD!
     */
    public function enqueue_admin_assets($hook) {
        // Chỉ load trên trang của plugin
        if (strpos($hook, 'vr360') === false) {
            return;
        }
        
        // ═══════════════════════════════════════
        // ⭐ LOAD MARZIPANO LIBRARY
        // ═══════════════════════════════════════
        wp_enqueue_script(
            'marzipano',
            VR360_PLUGIN_URL . 'assets/marzipano/marzipano.js',
            array(),
            '0.10.2',
            true
        );
        
        // ═══════════════════════════════════════
        // ⭐ LOAD DASHBOARD CSS/JS
        // (CSS từ mockup "VR360 Studio - Dashboard")
        // ═══════════════════════════════════════
        if (strpos($hook, 'vr360-dashboard') !== false) {
            wp_enqueue_style(
                'vr360-dashboard-css',
                VR360_PLUGIN_URL . 'assets/css/dashboard.css',
                array(),
                VR360_VERSION
            );
            
            wp_enqueue_script(
                'vr360-dashboard-js',
                VR360_PLUGIN_URL . 'assets/js/dashboard.js',
                array('jquery'),
                VR360_VERSION,
                true
            );
        }
        
        // ═══════════════════════════════════════
        // ⭐ LOAD EDITOR CSS/JS
        // (CSS từ mockup "VR360 Editor Interface")
        // ═══════════════════════════════════════
        if (strpos($hook, 'vr360-editor') !== false) {
            wp_enqueue_style(
                'vr360-editor-css',
                VR360_PLUGIN_URL . 'assets/css/editor.css',
                array(),
                VR360_VERSION
            );
            
            wp_enqueue_script(
                'vr360-editor-js',
                VR360_PLUGIN_URL . 'assets/js/editor.js',
                array('jquery', 'marzipano'),
                VR360_VERSION,
                true
            );
        }
        
        // ═══════════════════════════════════════
        // ⭐ LOCALIZE SCRIPT (Pass data từ PHP → JS)
        // ═══════════════════════════════════════
        wp_localize_script('vr360-dashboard-js', 'vr360_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vr360_nonce'),
            'user_id' => get_current_user_id(),
            'plugin_url' => VR360_PLUGIN_URL,
        ));
    }
}

// ═══════════════════════════════════════
// ⭐ KHỞI ĐỘNG PLUGIN
// ═══════════════════════════════════════
function vr360_studio_init() {
    return VR360_Studio::get_instance();
}

// Start the plugin!
vr360_studio_init();